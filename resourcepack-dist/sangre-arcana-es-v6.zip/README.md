# Resourcepack "Sangre Arcana ES"

Traduce al español los mods que quedan en inglés, **sin tocar los jars** (MD5 estable → el launcher
no se rompe). Es un resourcepack normal que se activa en el cliente.

- `pack_format: 15` = Minecraft 1.20.1 (correcto para Forge 1.20.1).
- Lista completa de los **103 mods en inglés**: `../mods-en-ingles.txt` (raíz del repo).

## Cómo añadir un idioma (patrón)
Por cada mod a traducir:
1. Abrir su jar y copiar `assets/<modid>/lang/en_us.json`.
2. Crear aquí `assets/<modid>/lang/es_es.json` con las **mismas claves**, traduciendo solo los **valores**.
3. No traducir nombres propios de marca ni IDs; respetar `%s`, `%1$s`, códigos `§`/`&` y saltos `\n`.
4. Probar in-game con el idioma del juego en Español (ES).

> El `<modid>` casi nunca es el nombre del jar. Sácalo del `META-INF` / `mods.toml` del jar
> o de la carpeta dentro de `assets/`.

## Prioridad ALTA (traducir primero — lo que el jugador LEE constantemente)
- `reskillable` — texto de skills/locks (visible al craftear/usar). Ejemplo incluido abajo.
- `regions_unexplored` (RegionsUnexplored) — nombres de biomas.
- Mobs/armas que el jugador ve seguido: `celestisynth`, `samurai_dynasty`, `weaponmaster_ydm`,
  `naturalist`, `endermanoverhaul`, `recrafted_creatures`, `born_in_chaos`, `legendarymonsters`.
- QoL muy visible: `bountiful` (bounties), `goblintraders`, `aquaculture`/`stardew_fishing`.

## Prioridad MEDIA / BAJA
Resto de `mods-en-ingles.txt` (estructuras, libs, decoración) — traducir después; muchos casi no
muestran texto al jugador.

## Estructura
```
resourcepack-es/
  pack.mcmeta
  assets/
    reskillable/lang/es_es.json      # ejemplo/patrón (rellenar contra el en_us real)
    regions_unexplored/lang/es_es.json
    <modid>/lang/es_es.json ...
```
